defmodule TestingstuffTest do
  use ExUnit.Case
  doctest Testingstuff

  test "greets the world" do
    assert Testingstuff.hello() == :world
  end
end
