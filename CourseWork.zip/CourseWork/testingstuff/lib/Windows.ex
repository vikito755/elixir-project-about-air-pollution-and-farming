defmodule Windows do

use Agent

#Agen which hold the state of the window
def start_link() do
  Agent.start_link(fn -> "closed" end , name: __MODULE__)
end
#shows the state of the window
def window() do
  Agent.get( __MODULE__ , & &1 )
end
#opens the window
def open do
 Agent.get_and_update( __MODULE__ , fn state -> {state, "opened"} end)
end
#closes the window
def closed do
  Agent.get_and_update( __MODULE__ , fn state -> {state, "closed"} end)
end

#helper function which makes requests to the api and changes the state of the window accordingly
  def hello do


    api = "https://api.openaq.org/v1/latest?city=London&parameter=pm10&location=Thurrock"

    {:ok,%HTTPoison.Response{body: res}} =HTTPoison.get(api)

      res =  Jason.decode!(res)

      deeper = Map.get(res, "results")
      Enum.reduce( deeper , fn  x , acc ->
         x["measurements"]
    something =   [acc] ++ [x]

  end)


  test =  Enum.reduce(deeper , 0  , fn x , acc ->
     [value] = x["measurements"]

  acc = cond do
      value["value"]  >= acc ->
     value["value"]
      true -> acc end



w = Windows.window()

if acc < 50 && w == "closed" do
  IO.puts("air is clean")


  IO.puts("window is opening")
  open()
  IO.puts ("window is opened")
end

if acc < 50 && w =="opened" do
  IO.puts("air is clean")
  IO.puts("window is already opened")
end

if acc > 50 && w == "opened" do
  IO.puts ("air is not clean")

  IO.puts ("window is closing")
closed()
  IO.puts("window is closed")
end

if acc >50 && w == "closed" do
  IO.puts ("air is not clean")

  IO.puts ("window is already closed")
end


  end

)





  end



end
