defmodule THEALLSEEINGONE do
#A supervising module it runs all the genservers and when one crashes restarts them all
  use Supervisor

  def start_link do
    Supervisor.start_link(__MODULE__ , [])
  end

  def init([]) do
    children = [
      worker(GenWindows, []),
      worker(GenWeather, []),
      worker(GenFridge,[])


    ]

    supervise(children, strategy: :one_for_all)
  end


end
