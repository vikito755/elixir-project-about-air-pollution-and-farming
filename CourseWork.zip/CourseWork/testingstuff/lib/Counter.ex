defmodule Counter do
#implements a counter that ticks up and when it reaches a sertain point rots the products in the list (needs more work)
use Agent

def start_link() do
  Agent.start_link(fn -> 0 end, name: __MODULE__)
end

def value do
  Agent.get(__MODULE__, & &1)
end

def increment do
  Agent.update(__MODULE__, &(&1 + 1))
end

def roting do

milk_products = %{:milk => 2 , :chesse => 3}

Enum.reduce(milk_products , 0 , fn x , acc ->
    {mil_product , days_untill_rot } = x
    days_untill_rt = value()

    if days_untill_rt  == days_untill_rot do
    IO.puts("Product: #{mil_product} is rotten")
   end end)


end

end
