defmodule FridgeDoor do
#Saves the state of the fridge door and contains functions for changing the state of the door
  use Agent

  def start_link() do
    Agent.start_link(fn -> "closed" end , name: __MODULE__)
  end

  def fridge_door() do
    Agent.get( __MODULE__ , & &1 )
  end

  def open do
   Agent.get_and_update( __MODULE__ , fn state -> {state, "opened"} end)
  end

  def closed do
    Agent.get_and_update( __MODULE__ , fn state -> {state, "closed"} end)
  end


end
