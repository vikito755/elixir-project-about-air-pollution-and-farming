defmodule Weather do

use Agent


#a helper function that makes requests to the api.
def requests(wheredoyougo , whichvariable) do

  api = "api.openweathermap.org/data/2.5/weather?q=London,uk&APPID=4ababce7c5700a7c680848d62336da46"

 {:ok,%HTTPoison.Response{body: res}} =HTTPoison.get(api)

 res = Jason.decode! (res)

deeper =  Map.get(res , wheredoyougo)


  if is_list(deeper) do

    Enum.reduce(deeper , 0  , fn x , acc -> x[whichvariable] end) #kak da napravq taka che x da se promenq dinamichno (nezavisimo dali e map ili list)
  else deeper[whichvariable]
  end

end

#The code untill the next comment implements an agent that makes a request to the api and saves the value of the request in the agents state
  Agent.start_link(fn -> requests("main" , "humidity") end , name: __MODULE__)
end
def start_link do

def humidity() do
  Agent.get(__MODULE__ , & &1)
end

def updatehumidity do
  Agent.get_and_update(__MODULE__ , fn state -> {state , requests("main" , "humidity")} end)
end

def humidity_minus do
  Agent.get_and_update( __MODULE__ , fn state -> {state, state - 10} end)
end

def minushumidity do
  if humidity() > 20 && Windows.window == "closed" do
    humidity_minus()
    minushumidity()
  else IO.puts(humidity())
  end

  if humidity() < 20 && Windows.window == "opened" do
    IO.puts("moisture absorber has stopped")
  end

end


#Calls the requests helper function and depending on the value turns on the solar pannels or not
def solar_pannels do
  value_solar_pannels =  requests("weather" , "main")

    if value_solar_pannels == "Sunny" do
        IO.puts("Solar Pannels are on!")
    else  IO.puts ("solar pannels are not on ...")
  end


end

#Calls the requests helper function and depending on the value turns on the fan or not
def fan do
  value_fan =  requests("main" , "temp")
IO.inspect(value_fan)
    if value_fan > 303 do
        IO.puts("Fan is on")
    else  IO.puts ("fan is not on ...")
  end



end

#The following code makes 2 requests to the api when called in the functions bellow it compares the values in the maps to the result from the api and returns a massage according to the value
def wind_speed do
speed  = requests("wind" , "speed")

end

def wind_deg do
  def = requests("wind" , "deg")
end

def wind_state do


  speed_map = %{:calm => 0..1 , :light_air => 1..2 ,:light_breeze => 3..4 , :gentle_breeze => 5..6 , :moderate_breeze => 7..8 ,:fresh_breeze => 9..10 ,:strong_breeze => 11..12 ,:high_wind => 13..14 ,:gale => 15..16 ,
   :strong_gale => 17..18 , :storm => 19..20 , :violent_storm => 20 .. 21 }

wind_st =  Enum.reduce(speed_map , 0 , fn x , acc ->
    {wind_state , range } = x
    equ = wind_speed()
    |> round
  variable =  if equ  in range do
      wind_state

      IO.puts("wind is #{wind_state}")
    end



  end  )

  wind_degree = %{:N => 348..360 , :NNE => 11..33 , :NE => 34..56 , :ENE => 57..78 , :E => 79..101 , :ESE => 102..123 , :SE => 124..146,
:SSE => 147..168 , :S => 169..191 , :SSW => 192..213 , :SW => 214..236 , :WSW =>237..258 , :W => 259..281 , :WNW => 282..303 , :NW => 304..326 , :NNW => 327..347 }

wind_de = Enum.reduce(wind_degree , 0 , fn x , acc ->
  {wind_degree , range} = x
  equ = wind_deg()
  |>round
  variable = if equ in range do
    wind_degree

    IO.puts("Wind comes from #{wind_degree}")
  end

   end)

end





end
