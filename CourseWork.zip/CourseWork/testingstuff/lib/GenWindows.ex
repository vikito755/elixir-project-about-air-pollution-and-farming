defmodule GenWindows do
#a gensergver that periodically implements the functions in the Windows module 
use GenServer

def start_link do
  GenServer.start_link(__MODULE__, %{})
end

def init(state) do
  Windows.start_link
  handle_info(:work , state)
{:ok,state}
end

def handle_info(:work , state)do
Windows.hello()
run()
{:noreply , state}
end

defp run() do
  Process.send_after(self() , :work , 6 * 10000)
end

end
