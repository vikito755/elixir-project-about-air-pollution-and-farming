defmodule Shortername do
#Implements an agent that hold a must have products in the fridge and a function that updates the list to contain no products 
  use Agent

  def start_link()do
    Agent.start_link(fn -> ["Cheasse" , "Tomato" , "Bread"] end , name: __MODULE__)
  end

  def list() do
    Agent.get(__MODULE__ , & &1)
  end

  def update_list do
   Agent.get_and_update( __MODULE__ , fn state -> {state, []} end)
  end

end
