defmodule GenFridge do
use GenServer
#Implements the functionalities from Counter Shortername and FridgeDoor
def start_link do
  GenServer.start_link(__MODULE__ , %{})
end

def init(state) do
    Counter.start_link
    Shortername.start_link
    FridgeDoor.start_link
    handle_info(:work , state)
    {:ok , state}
end

def handle_info(:work , state)do
  Shortername.update_list
  Counter.increment
  Counter.roting
  run()
  {:noreply , state}
end

defp run() do
  Process.send_after(self() , :work , 6 *1000)
end

end
