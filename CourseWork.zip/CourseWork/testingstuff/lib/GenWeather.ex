defmodule GenWeather do
use GenServer
#a gensergver that periodically implements the functions in the Weather module
def start_link do
  GenServer.start_link(__MODULE__ , %{})
end

def init(state) do
    Weather.start_link
    handle_info(:work , state)
    {:ok , state}
end

def handle_info(:work , state)do
  Weather.minushumidity
  Weather.solar_pannels
  Weather.fan
  Weather.wind_state
  run()
  {:noreply , state}
end

defp run() do
  Process.send_after(self() , :work , 6 *10000)
end

def update_humidity(:update ,state) do
  Weather.updatehumidity
  update()
end

defp update() do
  Process.send_after(self() , :update , 12 *10000)
end


end
